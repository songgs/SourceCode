﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    public enum Severity : byte
    {
        Trivial,
        Minor,
        Major,
        Showstopper,
    }
}
