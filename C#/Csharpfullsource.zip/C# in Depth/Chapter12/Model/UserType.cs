﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    public enum UserType : byte
    {
        Customer,
        Developer,
        Tester,
        Manager,
    }
}
