﻿namespace Chapter03.Variance
{
    public interface IShape
    {
        double Area { get; }
    }
}
