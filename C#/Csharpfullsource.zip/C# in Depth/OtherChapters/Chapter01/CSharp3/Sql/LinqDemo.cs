namespace Chapter01.CSharp3.Sql
{
    partial class LinqDemoDataContext
    {
    }
}
